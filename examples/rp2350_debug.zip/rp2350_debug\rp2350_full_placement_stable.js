// Stable compact RP2350A placement graph.
board.roundedRect(25, 60, {
  radius: 1.5,
  segments: 8,
  layers: ["top", "bottom"],
  defaultLayer: "top",
  clearance: 0.30,
  edge: 0.35,
});

silkscreen.designators({ height: 0.75, rotations: [0, 90], margin: 0.18 });

// Hard mechanical corridors: only the matching edge hardware may occupy them.
constraintRegion("left_header_corridor", {
  allow: { blocks: ["gpio_left"] },
  layers: ["top", "bottom"],
  shape: region.rect({ anchor: anchor("board.left"), width: 3.3, height: 60 }),
});
constraintRegion("right_header_corridor", {
  allow: { blocks: ["gpio_right"] },
  layers: ["top", "bottom"],
  shape: region.rect({ anchor: anchor("board.right"), width: 3.3, height: 60 }),
});
constraintRegion("usb_entry", {
  allow: { blocks: ["usb_c", "usb_cc", "gpio_left", "gpio_right"] },
  layers: ["top", "bottom"],
  shape: region.rect({ anchor: anchor("board.top"), width: 25, height: 7.5 }),
});

// Fixed mechanics.
block("usb_c", ["J1"], "connector", { placement: "main", anchor: anchor("board.top") });
block("swd_header", ["J2"], "connector", { placement: "main", anchor: anchor("board.bottom") });
block("gpio_left", ["J3"], "connector", { placement: "main", anchor: anchor("board.left") });
block("gpio_right", ["J4"], "connector", { placement: "main", anchor: anchor("board.right") });
block("bootsel_button", ["SW1"], "connector", { placement: "main", anchor: anchor("board.top") });
block("run_button", ["SW2"], "connector", { placement: "main", anchor: anchor("board.top") });

component("J3").block("gpio_left").role("connector").top().fixed({ x: -10.85, y: 0, rotate: 90, layer: "top" });
component("J4").block("gpio_right").role("connector").top().fixed({ x: 10.85, y: 0, rotate: 90, layer: "top" });
component("J1").block("usb_c").role("connector").top()
  .edgeMount("top", { overhang: 2.2, x: 0, layer: "top", face: "outward" });
component("J2").block("swd_header").role("connector").top()
  .fixed({ x: 0, y: 26.5, rotate: 180, layer: "top" }).faceTo("board.bottom");
component("SW1").block("bootsel_button").role("connector").top().fixed({ x: -3.5, y: -19.5, rotate: 0, layer: "top" });
component("SW2").block("run_button").role("connector").top().fixed({ x: 3.5, y: -19.5, rotate: 0, layer: "top" });

// Functional blocks. Each is a single physical/electrical island.
block("usb_cc", ["R5", "R6"], "connector", {
  placement: "main", anchor: anchor("board.top"), allowDisconnected: true,
});
block("power_ldo", ["U1"], "power", { placement: "main", anchor: anchor("board.top") });
block("ldo_input_cap", ["C1"], "power", {
  placement: "satellite", attachTo: "power_ldo", anchor: pin("U1", "3"),
});
block("ldo_output_cap", ["C2"], "power", {
  placement: "satellite", attachTo: "power_ldo", anchor: pin("U1", "2"),
});
block("mcu_core", ["U2"], "mcu", { placement: "main", anchor: anchor("board.center") });
block("mcu_clock", ["Y1", "R1", "C3", "C4"], "mcu", {
  placement: "main", anchor: pin("U2", "21"),
});
block("buck_switch", ["L1", "C6"], "power", {
  placement: "main", anchor: pin("U2", "48"),
});
block("buck_feedback", ["C8"], "power", {
  placement: "main", anchor: pin("U2", "50"),
});
block("buck_input", ["C5"], "power", {
  placement: "main", anchor: pin("U2", "49"),
});
block("vreg_filter_r", ["R2"], "analog", {
  placement: "main", anchor: pin("U2", "46"),
});
block("vreg_filter_c", ["C7"], "analog", {
  placement: "main", anchor: pin("U2", "46"),
});
block("iovdd_pin1", ["C9"], "mcu", {
  placement: "main", anchor: pin("U2", "1"),
});
block("iovdd_pin11", ["C10"], "mcu", {
  placement: "main", anchor: pin("U2", "11"),
});
block("iovdd_pin20", ["C11"], "mcu", {
  placement: "main", anchor: pin("U2", "20"),
});
block("iovdd_pin30", ["C12"], "mcu", {
  placement: "main", anchor: pin("U2", "30"),
});
block("iovdd_pin38", ["C13"], "mcu", {
  placement: "main", anchor: pin("U2", "38"),
});
block("iovdd_pin45", ["C14"], "mcu", {
  placement: "main", anchor: pin("U2", "45"),
});
block("dvdd_pin6", ["C15"], "mcu", {
  placement: "main", anchor: pin("U2", "6"),
});
block("dvdd_pin23", ["C16"], "mcu", {
  placement: "main", anchor: pin("U2", "23"),
});
block("dvdd_pin39", ["C17"], "mcu", {
  placement: "main", anchor: pin("U2", "39"),
});
block("adc_avdd_pin44", ["C18"], "analog", {
  placement: "main", anchor: pin("U2", "44"),
});
block("usb_otp_pin53", ["C19"], "analog", {
  placement: "main", anchor: pin("U2", "53"),
});
block("qspi_iovdd_pin54", ["C20"], "mcu", {
  placement: "main", anchor: pin("U2", "54"),
});
block("qspi_flash", ["U3", "C21"], "mcu", {
  placement: "main", anchor: anchor("board.bottom"),
});
block("usb_dm_series", ["R3"], "mcu", {
  placement: "main", anchor: pin("U2", "51"), allowDisconnected: true,
});
block("usb_dp_series", ["R4"], "mcu", {
  placement: "main", anchor: pin("U2", "52"), allowDisconnected: true,
});

component("U1").block("power_ldo").role("main_ic").top();
component("U2").block("mcu_core").role("main_ic").top();
component("U3").block("qspi_flash").role("main_ic").top();
component("Y1").block("mcu_clock").role("crystal").top();
component("L1").block("buck_switch").role("passive").top();
["C1","C2","C5","C6","C7","C8","C9","C10","C11","C12","C13","C14","C15","C16","C17","C18","C19","C20"]
  .forEach(d => component(d).role("decoupling_cap").top());
["C3","C4","C21"].forEach(d => component(d).role("decoupling_cap").top());
["R2","R3","R4"].forEach(d => component(d).role("passive").top());
["R1","R5","R6"].forEach(d => component(d).role("passive").top());

// Deterministic RP2350A escape placement.  Supply capacitors are distributed
// around the four package sides, with their powered pads facing the target pins.
// Keeping these positions explicit prevents the global solver from collecting
// the bypass network into a visually compact but electrically poor cluster.
component("U2").role("connector").fixed({ x: 0, y: 8, rotate: 180, layer: "top" });

component("C9").role("connector").fixed({ x: -5.6, y: 5.2, rotate: 0, layer: "top" });
component("C15").role("connector").fixed({ x: -5.6, y: 7.2, rotate: 0, layer: "top" });
component("C10").role("connector").fixed({ x: -5.6, y: 9.2, rotate: 0, layer: "top" });

component("C11").role("connector").fixed({ x: -2.55, y: 13.6, rotate: 270, layer: "top" });
component("C16").role("connector").fixed({ x: 0.65, y: 13.6, rotate: 270, layer: "top" });
component("C12").role("connector").fixed({ x: 4.5, y: 13.6, rotate: 270, layer: "top" });

component("C14").role("connector").fixed({ x: 7.45, y: 5.8, rotate: 180, layer: "top" });
component("C18").role("connector").fixed({ x: 7.45, y: 7.2, rotate: 180, layer: "top" });
component("C17").role("connector").fixed({ x: 7.45, y: 8.55, rotate: 180, layer: "top" });
component("C13").role("connector").fixed({ x: 5.8, y: 10.0, rotate: 180, layer: "top" });

component("C19").role("connector").fixed({ x: -1.2, y: 2.35, rotate: 90, layer: "top" });
component("C20").role("connector").fixed({ x: -2.6, y: 2.35, rotate: 90, layer: "top" });

// The remaining high-speed/power support is floorplanned into dedicated lanes.
component("R4").role("connector").fixed({ x: 0.2, y: 2.35, rotate: 90, layer: "top" });
component("R3").role("connector").fixed({ x: 1.6, y: 2.35, rotate: 90, layer: "top" });
component("C8").role("connector").fixed({ x: 3.2, y: 1.9, rotate: 90, layer: "top" });
component("L1").role("connector").fixed({ x: 5.45, y: 1.5, rotate: 90, layer: "top" });
component("C6").role("connector").fixed({ x: 7.7, y: 1.5, rotate: 90, layer: "top" });
component("C5").role("connector").fixed({ x: 0.0, y: 0.2, rotate: 0, layer: "top" });
component("R2").role("connector").fixed({ x: 5.7, y: 4.45, rotate: 0, layer: "top" });
component("C7").role("connector").fixed({ x: 5.45, y: 6.75, rotate: 270, layer: "top" });

component("Y1").role("connector").fixed({ x: -1.0, y: 16.65, rotate: 0, layer: "top" });
component("R1").role("connector").fixed({ x: 2.05, y: 14.7, rotate: 270, layer: "top" });
component("C3").role("connector").fixed({ x: -4.0, y: 13.6, rotate: 90, layer: "top" });
component("C4").role("connector").fixed({ x: -1.0, y: 19.5, rotate: 0, layer: "top" });

near(block("power_ldo"), block("usb_c"), "critical");
near(block("mcu_core"), anchor("board.center"), "critical");
away(block("mcu_clock"), block("buck_switch"), "high");
blockClearance("mcu_clock", "gpio_left", 1.0, "critical");
blockClearance("buck_switch", "gpio_right", 1.0, "critical");
blockClearance("qspi_flash", "gpio_right", 1.0, "critical");

criticalPair(pin("U2", "48"), pin("L1", "1"), { maxDistance: 5.0, hard: true, weight: 10, preferFacingPads: true });
criticalPair(pin("Y1", "1"), pin("U2", "21"), { maxDistance: 6.0, weight: 8, preferFacingPads: true });
criticalPair(pin("R1", "1"), pin("U2", "22"), { maxDistance: 6.0, weight: 8, preferFacingPads: true });
criticalPair(pin("U3", "6"), pin("U2", "56"), { maxDistance: 12.5, weight: 7, preferFacingPads: true });

// One exact pad-to-pad bypass constraint per RP2350A supply pin.
corePairs("rp2350_supply_bypass", [
  [pin("C9", "1"), pin("U2", "1")],
  [pin("C10", "1"), pin("U2", "11")],
  [pin("C11", "1"), pin("U2", "20")],
  [pin("C12", "1"), pin("U2", "30")],
  [pin("C13", "1"), pin("U2", "38")],
  [pin("C14", "1"), pin("U2", "45")],
  [pin("C15", "1"), pin("U2", "6")],
  [pin("C16", "1"), pin("U2", "23")],
  [pin("C17", "1"), pin("U2", "39")],
  [pin("C18", "1"), pin("U2", "44")],
  [pin("C19", "1"), pin("U2", "53")],
  [pin("C20", "1"), pin("U2", "54")],
], { maxDistance: 3.8, hard: true, weight: 9, preferFacingPads: true });

criticalPair(pin("C11", "1"), pin("U2", "20"), {
  maxDistance: 2.8, hard: true, weight: 15, preferFacingPads: true,
});

corePairs("rp2350_buck_local", [
  [pin("U2", "48"), pin("L1", "1")],
  [pin("U2", "49"), pin("C5", "1")],
  [pin("L1", "2"), pin("C6", "1")],
  [pin("U2", "50"), pin("C8", "1")],
  [pin("U2", "46"), pin("R2", "2")],
  [pin("U2", "46"), pin("C7", "1")],
], { maxDistance: 5.2, hard: true, weight: 11, preferFacingPads: true });

corePairs("rp2350_clock_local", [
  [pin("U2", "21"), pin("Y1", "1")],
  [pin("U2", "22"), pin("R1", "1")],
  [pin("R1", "2"), pin("Y1", "3")],
  [pin("C3", "1"), pin("U2", "21")],
  [pin("C4", "1"), pin("Y1", "3")],
], { maxDistance: 5.5, hard: true, weight: 10, preferFacingPads: true });

corePairs("rp2350_usb_series_local", [
  [pin("U2", "51"), pin("R3", "2")],
  [pin("U2", "52"), pin("R4", "2")],
], { maxDistance: 3.5, hard: true, weight: 10, preferFacingPads: true });

criticalPair(pin("U3", "8"), pin("C21", "1"), {
  maxDistance: 3.0, hard: true, weight: 10, preferFacingPads: true,
});

corePairs("ldo_local_bypass", [
  [pin("U1", "3"), pin("C1", "1")],
  [pin("U1", "2"), pin("C2", "1")],
], { maxDistance: 4.0, hard: true, weight: 9, preferFacingPads: true });

solver({ grid: 0.5, ignoredSignals: ["GND"], compactness: "normal" });
